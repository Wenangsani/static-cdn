use crate::model::test::Test;
use crate::model::test::TestList;
use crate::db::{MySqlPooledConnection, MysqlPool};

use actix_web::{web, HttpRequest, HttpResponse};

fn connect(pool: web::Data<MysqlPool>) -> Result<MySqlPooledConnection, HttpResponse> {
    pool.get().map_err(|e| HttpResponse::InternalServerError().json(e.to_string()))
}

pub async fn list(_req: HttpRequest, pool: web::Data<MysqlPool>,) -> Result<HttpResponse, HttpResponse> {
    let connection = connect(pool)?;
    let list = HttpResponse::Ok().json(TestList::list(&connection, 10));
    Ok(list)
}

pub async fn item(_req: HttpRequest, pool: web::Data<MysqlPool>,) -> Result<HttpResponse, HttpResponse> {
    let connection = pool.get().expect("Error connection from pool");
    let list = HttpResponse::Ok().json(Test::item(&connection));
    Ok(list)
}