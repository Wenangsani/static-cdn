// use crate::schema::test;
// use chrono::NaiveDateTime;
use diesel::MysqlConnection;

#[derive(Queryable, Serialize, Deserialize, Debug)]
pub struct Test {
    pub id: i32,
    pub name: String,
}

#[derive(Serialize, Deserialize)]
pub struct TestList(pub Vec<Test>);

impl TestList {
    pub fn list(connection: &MysqlConnection, limit: i64) -> Self {
        use crate::schema::test::dsl::*;
        use diesel::QueryDsl;
        use diesel::RunQueryDsl;

        let result = test
            .limit(limit)
            .load::<Test>(connection)
            .expect("Error loading tests");

        TestList(result)
    }
}

impl Test {
    pub fn item(connection: &MysqlConnection) -> Self {
        use crate::schema::test::dsl::*;
        use diesel::RunQueryDsl;

        let result = test
            .first::<Test>(connection)
            .expect("Error loading tests");

        result    
    }
}