#[macro_use]
extern crate diesel;
extern crate serde;
extern crate serde_json;
#[macro_use]
extern crate serde_derive;

pub mod db;
pub mod handlers;
pub mod model;
pub mod schema;

use actix_web::{web, App, HttpServer};
use db::connect;

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new()
        .data(connect())
        .route("/item", web::get().to(handlers::test::item))
        .route("/list", web::get().to(handlers::test::list))
    })
    .bind("127.0.0.1:8080")?
    .run()
    .await
}