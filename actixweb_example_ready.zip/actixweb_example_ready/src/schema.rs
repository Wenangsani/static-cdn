table! {
    test (id) {
        id -> Integer,
        name -> Varchar,
    }
}
